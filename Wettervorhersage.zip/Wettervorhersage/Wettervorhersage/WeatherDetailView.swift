import SwiftUI

struct WeatherDetailView: View {
    
    var weathermap: Weathermap
    let currentDay = Calendar.current.component(.weekday, from: Date())
    let pictures = ["cloud.sun.fill", "sun.max.fill","wind.snow","snow","cloud.sun.fill","cloud.fill","cloud.bolt.fill","cloud.bolt.rain.fill","cloud.fog.fill","cloud.rain.fill","cloud.sleet.fill","cloud.snow.fill","cloud.sun.rain.fill","cloud.hail.fill"]
    
    func getDayOfWeek(day: Int) -> String {
        switch day {
            case 1:
                return "Mon"
            case 2:
                return "Tue"
            case 3:
                return "Wed"
            case 4:
                return "Thu"
            case 5:
                return "Fri"
            case 6:
                return "Sat"
            case 7:
                return "Sun"
            default:
                return "Error"
            }
    }
    
    var body: some View {
        
        ZStack {
            
            LinearGradient(gradient:Gradient(colors: [.blue, .white]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
            
            VStack{
                
                Text(weathermap.city)
                    .font(.system(size: 32, weight: .medium, design: .default))
                    .foregroundColor(.white).padding(20)
                
                VStack(spacing:10){
                    
                    Image(systemName: weathermap.icon)
                        .renderingMode(.original)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 180, height: 180)
                    
                    Text(weathermap.temp + "°")
                        .font((.system(size: 70, weight: .medium)))
                        .foregroundColor(.white)
                }
                .padding(.bottom, 40)
                //Spacer()
                HStack(spacing: 18){
                    WeatherDayView(dayOfWeek: getDayOfWeek(day: (currentDay) % 7), imageName: pictures[Int.random(in: 0..<self.pictures.count)], temperature: Int.random(in: -5...8))
                    WeatherDayView(dayOfWeek: getDayOfWeek(day: (currentDay+1) % 7), imageName: pictures[Int.random(in: 0..<self.pictures.count)], temperature: Int.random(in: -5...8))
                    WeatherDayView(dayOfWeek: getDayOfWeek(day: (currentDay+2) % 7), imageName: pictures[Int.random(in: 0..<self.pictures.count)], temperature: Int.random(in: -5...8))
                    WeatherDayView(dayOfWeek: getDayOfWeek(day: (currentDay+3) % 7), imageName: pictures[Int.random(in: 0..<self.pictures.count)], temperature: Int.random(in: -5...8))
                    WeatherDayView(dayOfWeek: getDayOfWeek(day: (currentDay+4) % 7), imageName: pictures[Int.random(in: 0..<self.pictures.count)], temperature: Int.random(in: -5...8))
                    WeatherDayView(dayOfWeek: getDayOfWeek(day: (currentDay+5) % 7), imageName: pictures[Int.random(in: 0..<self.pictures.count)], temperature: Int.random(in: -5...8))
                }.padding(.bottom, 90)
            }
            .offset(y: -50)
        }
    }
}

struct WeatherDetailView_Previews: PreviewProvider {
    static var previews: some View {
        WeatherDetailView(weathermap: Weathermap(id: "1", city: "Hamm", temp: "5", icon: "wind.snow"))
    }
}

struct WeatherDayView: View {
    var dayOfWeek: String
    var imageName: String
    var temperature: Int
    
    var body: some View {
        VStack{
            
            Text(dayOfWeek)
                .font(.system(size: 16, weight: .medium, design: .default))
                .foregroundColor(.white)
            Image(systemName: imageName)
                .renderingMode(.original)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 45, height: 45)
            
            Text("\(temperature)°")
                .font((.system(size: 28, weight: .medium)))
                .foregroundColor(.white)
        }
    }
}
