import Foundation

struct Weathermap: Codable{
    
    let id: String
    let city: String
    let temp: String
    let icon: String
}
