import Foundation

@MainActor
class Service: ObservableObject {
    
    @Published var weathermaps: [Weathermap] = []

    func fetchWeather() async throws {
        
        let request = URLRequest(url: URL(string: "https://my-json-server.typicode.com/anastasiia215/weathermap/weather")!)
        let (data, _) = try await URLSession.shared.data(for: request)
        let response = try JSONDecoder().decode([Weathermap].self, from: data)
        weathermaps = response
    }
}
