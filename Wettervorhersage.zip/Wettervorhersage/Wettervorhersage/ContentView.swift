import SwiftUI

struct ContentView: View {
    
    @StateObject var service = Service()
    @State private var searchCity: String=""
    @State private var filteredCities: [Weathermap] = []
    
    private func performSearch(searchWord: String){
        filteredCities = service.weathermaps.filter {
            weathermap in weathermap.city.contains(searchWord)
        }
    }
    
    private var weathermaps: [Weathermap] {
        filteredCities.isEmpty ? service.weathermaps: filteredCities
    }
    
    var body: some View {
        
        NavigationView {
            
            ZStack{
                VStack{
                    
                    List(weathermaps, id: \.id) {
                        weathermap in
                        NavigationLink(destination: WeatherDetailView(weathermap: weathermap), label: {
                            Text(weathermap.city)
                        })
                    }
                    .searchable(text: $searchCity).onChange(of: searchCity, perform: performSearch)
                    .task {
                        do {
                            try await service.fetchWeather()
                        } catch {
                            print(error)
                        }
                    }
                    .navigationTitle("Cities")
                }
            }
        }.accentColor(Color(.label))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


