//
//  WettervorhersageApp.swift
//  Wettervorhersage
//
//  Created by student on 18.10.22.
//

import SwiftUI

@main
struct WettervorhersageApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
